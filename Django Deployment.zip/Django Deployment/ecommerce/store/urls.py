from django.urls import path
from .views import (
    ProductListView,
    ProductDetailView,
    # AddToFavoritesView,
    # RemoveFromFavoritesView,
    FavoritesView,
    ToggleFavoriteView,
    RecentlyViewedView,
    CartView,
    CheckoutView,
    OrderConfirmationView,
    SignupView,
    CustomLogoutView,
    CustomLoginView,
    UpdateCartView,
    UserProfileView,
    MyOrdersView,
    UserProfileUpdateView
)
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path("", ProductListView.as_view(), name="product_list"),
    path('product/<int:product_id>/', ProductDetailView.as_view(), name='product_detail'),
    path('toggle-favorite/<int:product_id>/', ToggleFavoriteView.as_view(), name='toggle_favorite'),  # URL for toggling favorite
    path('favorites/', FavoritesView.as_view(), name='favorites'),  # URL for favorites page
    # path('add_to_favorites/<int:product_id>/', AddToFavoritesView.as_view(), name='add_to_favorites'),
    # path('remove_from_favorites/<int:product_id>/',RemoveFromFavoritesView.as_view(), name='remove_from_favorites'),
    # path('favorites/',FavoritesView.as_view(), name='favorites_view'),
    path('recently-viewed/',RecentlyViewedView.as_view(), name='recently_viewed'),
    # path("product/<int:pk>/", ProductDetailView.as_view(), name="product_detail"),
    path("cart/", CartView.as_view(), name="cart_summary"),
    path('cart/update/', UpdateCartView.as_view(), name='update_cart'),
    path("checkout/", CheckoutView.as_view(), name="checkout"),
    path("order-confirmation/<int:pk>/", OrderConfirmationView.as_view(), name="order_confirmation"),
    path("signup/", SignupView.as_view(), name="signup"),
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', CustomLogoutView.as_view(), name='logout'),
    path('my-orders/', MyOrdersView.as_view(), name='my_orders'),
    path('profile/', UserProfileView.as_view(), name='profile'),  # For viewing the profile
    path('profile/edit/', UserProfileUpdateView.as_view(), name='edit_profile'),  # For editing the profile

 
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

   
   
   
