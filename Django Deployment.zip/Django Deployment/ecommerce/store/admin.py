from django.contrib import admin
from django.utils.html import format_html
from .models import Product, Category, Cart, CartItem, Order, OrderItem, UserProfile

# Admin for Category Model
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

admin.site.register(Category, CategoryAdmin)

# Admin for Product Model
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'price', 'stock', 'image_tag', 'created_at', 'updated_at')
    search_fields = ('name', 'category__name')
    list_filter = ('category',)
    ordering = ('-created_at',)
    list_per_page = 20

    # Custom function to display the image thumbnail in the admin list view
    def image_tag(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="50" height="50"/>'.format(obj.image.url))
        return "No Image"
    image_tag.short_description = 'Image'

admin.site.register(Product, ProductAdmin)



# Admin for CartItem Model
class CartItemAdmin(admin.ModelAdmin):
    list_display = ('cart', 'product', 'quantity')
    search_fields = ('cart__user__username', 'product__name')

admin.site.register(CartItem, CartItemAdmin)

# Admin for Order Model
class OrderAdmin(admin.ModelAdmin):
    list_display = ('user', 'order_status', 'payment_status', 'total_price', 'created_at', 'payment_screenshot_tag')
    search_fields = ('user__username',)
    list_filter = ('order_status', 'payment_status')
    ordering = ('-created_at',)

    # Custom method for displaying the total price in the list view
    def total_price(self, obj):
        return obj.total_price
    total_price.short_description = 'Total Price'

    # Custom method to display the payment screenshot in the admin list view
    def payment_screenshot_tag(self, obj):
        if obj.payment_screenshot:
            return format_html('<img src="{}" width="50" height="50"/>'.format(obj.payment_screenshot.url))
        return "No Image"
    payment_screenshot_tag.short_description = 'Payment Screenshot'

admin.site.register(Order, OrderAdmin)

# Admin for OrderItem Model
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'product', 'quantity', 'get_total_price')
    search_fields = ('order__user__username', 'product__name')

    # Custom method to display the total price of the order item
    def get_total_price(self, obj):
        return obj.get_total_price()
    get_total_price.short_description = 'Total Price'

admin.site.register(OrderItem, OrderItemAdmin)

# Admin for UserProfile Model
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user',)
    search_fields = ('user__username',)

admin.site.register(UserProfile, UserProfileAdmin)
