from django.db import models
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
from django.utils import timezone

# Custom validator for image size
def validate_image_size(image):
    max_size = 5 * 1024 * 1024  # 5MB
    if image.size > max_size:
        raise ValidationError(f"Image size should not exceed 5MB. Current size: {image.size / (1024 * 1024):.2f}MB")

# User Profile (optional, extend User model)
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    

    def __str__(self):
        return self.user.username

# Category Model
class Category(models.Model):
    name = models.CharField(max_length=100)
    
 
    def __str__(self):
        return self.name

# Product Model
class Product(models.Model):
    CATEGORY_TYPE_CHOICES = [
        ('Electronics', 'Electronics'),
        ('Fashion', 'Fashion'),
        ('Home & Kitchen', 'Home & Kitchen'),
    ]
    category_type = models.CharField(max_length=20, choices=CATEGORY_TYPE_CHOICES, default='Electronics')
    name = models.CharField(max_length=200)
    category = models.ForeignKey(Category, related_name="products", on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    stock = models.PositiveIntegerField()
    image = models.ImageField(upload_to='product_images/', validators=[validate_image_size])
    created_at = models.DateTimeField(auto_now_add=True)  # track creation date
    updated_at = models.DateTimeField(auto_now=True)     # track updates
   
    def __str__(self):
        return self.name
   
    def get_total_price(self, quantity):
        return self.price * quantity

# Cart Model
class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    products = models.ManyToManyField(Product, through='CartItem')

    is_ordered = models.BooleanField(default=False)

    def __str__(self):
        return f"Cart for {self.user.username}"

    def total_price(self):
        total = 0
        for item in self.cart_items.all():
            total += item.product.price * item.quantity
        return total

    def clear_cart(self):
        self.cart_items.all().delete()

    @staticmethod
    def get_or_create_cart(user):
        cart, created = Cart.objects.get_or_create(user=user, defaults={'is_ordered': False})
        if not created and cart.is_ordered:
            cart.is_ordered = False
            cart.save()
        return cart

# CartItem Model
class CartItem(models.Model):
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    cart = models.ForeignKey(Cart, related_name="cart_items", on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        if self.product:  # Check if the product exists
            return f"{self.quantity} x {self.product.name} in cart"
        return f"{self.quantity} x Product (Deleted or Not Assigned) in cart"

    def get_total_price(self):
        if self.product:  # Ensure the product exists before accessing its price
            return self.product.price * self.quantity
        return 0  # Return 0 if no product is assigned

    def clean(self):
        if self.product and self.quantity > self.product.stock:
            raise ValidationError(f"Cannot add more than {self.product.stock} items of {self.product.name} to the cart.")

# Order Model
class Order(models.Model):
    ORDER_STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Shipped', 'Shipped'),
        ('Delivered', 'Delivered'),
        ('Cancelled', 'Cancelled')
    ]
    PAYMENT_STATUS_CHOICES = [
        ('Unpaid', 'Unpaid'),
        ('Paid', 'Paid')
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(default=timezone.now)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    
    # Shipping address fields
    address_line1 = models.CharField(max_length=255, blank=True, null=True)
    address_line2 = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    state = models.CharField(max_length=100, blank=True, null=True)
    zip_code = models.CharField(max_length=20, blank=True, null=True)
    country = models.CharField(max_length=100, blank=True, null=True)
    
    order_status = models.CharField(max_length=10, choices=ORDER_STATUS_CHOICES, default='Pending')
    payment_status = models.CharField(max_length=10, choices=PAYMENT_STATUS_CHOICES, default='Unpaid')
    
    payment_screenshot = models.ImageField(upload_to='payment_screenshots/', blank=True, null=True)

    def __str__(self):
        return f"Order {self.id} by {self.user.username}"

    def update_total_price(self):
        total = 0
        for item in self.order_items.all():
            total += item.get_total_price()
        self.total_price = total
        self.save()
# OrderItem Model (Intermediate table for order-product relation)
class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name="order_items", on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True)
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2,default=0.00)

    def __str__(self):
        if self.product:  # Check if product exists
            return f"{self.quantity} x {self.product.name} in order"
        return f"{self.quantity} x Product (Deleted or Not Assigned) in order"

    def get_total_price(self):
        if self.product:
            return self.product.price * self.quantity
        return 0  # Return 0 if no product is assigned
