from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, View,TemplateView
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import login, logout, authenticate
from django.http import  HttpResponse
from .models import Product, Cart, CartItem, Order, UserProfile, OrderItem
from .forms import UserProfileForm, OrderForm,ProductSearchForm
from django.contrib import messages 
from django.views.generic.edit import UpdateView
from django.urls import reverse_lazy
from django.contrib.auth.models import User


class ProductListView(ListView):
    model = Product
    template_name = "store/product_list.html"
    context_object_name = "products"

    def get_queryset(self):
        queryset = Product.objects.all()
        
      
        query = self.request.GET.get('query')
        if query:
            queryset = queryset.filter(name__icontains=query)  
        
      
        category_type = self.request.GET.get('category_type')
        if category_type:
            queryset = queryset.filter(category_type=category_type)  
        
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['category_types'] = Product.CATEGORY_TYPE_CHOICES  
        context['search_form'] = ProductSearchForm()  
        return context



class ProductDetailView(View):
    def get(self, request, product_id):
        
        product = get_object_or_404(Product, id=product_id)
       
        
        recently_viewed = request.session.get('recently_viewed', [])
       
        # Add the current product to the recently viewed list if it's not already there
        if product.id not in recently_viewed:
            recently_viewed.append(product.id)
       
        # Keep the list size reasonable, e.g., 5 items
        if len(recently_viewed) > 5:
            recently_viewed.pop(0)  # Remove the oldest viewed product
       
        # Save the updated recently viewed list to the session
        request.session['recently_viewed'] = recently_viewed
 
        # Render the product detail page and pass the product and recently viewed list
        return render(request, 'store/product_detail.html', {
            'product': product,
            'recently_viewed': recently_viewed,
        })
 

 
class RecentlyViewedView(View):
    def get(self, request):
        # Get the list of recently viewed product IDs from the session
        recently_viewed = request.session.get('recently_viewed', [])
       
        # Fetch the products corresponding to these IDs (if any)
        products = Product.objects.filter(id__in=recently_viewed)
 
        # Render the recently viewed products page
        return render(request, 'store/recently_viewed.html', {
            'products': products
        })




 # Import messages to show error messages

class CartView(LoginRequiredMixin, View):
    def get(self, request):
        cart, created = Cart.objects.get_or_create(user=request.user, is_ordered=False)
        return render(request, "store/cart_summary.html", {"cart": cart})

    def post(self, request):
        if not request.user.is_authenticated:
            messages.error(request, "You need to sign up or log in to add products to the cart.")
            return redirect('product_list') 

        product_id = request.POST.get("product_id")
        quantity = int(request.POST.get("quantity", 1))  # Default to 1 if no quantity is provided
        action = request.POST.get("action", "add")  # Default action is "add"

        product = get_object_or_404(Product, id=product_id)
        cart, created = Cart.objects.get_or_create(user=request.user, is_ordered=False)

        if action == "add":
            # Check if the requested quantity exceeds the available stock
            if quantity > product.stock:
                messages.error(request, f"Cannot add {quantity} of {product.name} to the cart. Only {product.stock} in stock.")
                return redirect("product_detail", product_id=product.id)  # Redirect back to the product detail page
            # Add a product to the cart or update its quantity
            cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
            if created:
                cart_item.quantity = quantity
            else:
                cart_item.quantity += quantity
            cart_item.save()

        elif action == "increase":
            cart_item = get_object_or_404(CartItem, cart=cart, product=product)
            if cart_item.quantity < product.stock:
                cart_item.quantity += 1
                cart_item.save()
            else:
                messages.error(request, f"Cannot increase quantity of {product.name}. Only {product.stock} in stock.")

        elif action == "decrease":
            cart_item = get_object_or_404(CartItem, cart=cart, product=product)
            if cart_item.quantity > 1:
                cart_item.quantity -= 1
                cart_item.save()
            else:
                cart_item.delete()

        elif action == "delete":
            CartItem.objects.filter(cart=cart, product=product).delete()

        return redirect("cart_summary")



#Favorites

# views.py


class ToggleFavoriteView(View):
    def post(self, request, product_id):
        product = get_object_or_404(Product, id=product_id)

        # Initialize the favorite_products session variable if it doesn't exist
        if 'favorite_products' not in request.session:
            request.session['favorite_products'] = []

        # Toggle the product ID in the session
        if product.id in request.session['favorite_products']:
            request.session['favorite_products'].remove(product.id)  # Unfavorite
        else:
            request.session['favorite_products'].append(product.id)  # Favorite

        request.session.modified = True  # Mark the session as modified

        # Check the referer to determine where to redirect
        referer = request.META.get('HTTP_REFERER')
        if referer and 'favorites' in referer:
            return redirect('favorites')  # Redirect back to the favorites page
        else:
            return redirect('product_list')  # Redirect back to the product list





class FavoritesView(View):
    def get(self, request):
        # Get the list of favorite product IDs from the session
        favorite_product_ids = request.session.get('favorite_products', [])
        favorite_products = Product.objects.filter(id__in=favorite_product_ids)

        # Render the favorites page
        return render(request, 'store/favorites.html', {
            'favorite_products': favorite_products
        })



#  Carts
class UpdateCartView(LoginRequiredMixin, View):
    def post(self, request):
        cart_item_id = request.POST.get("cart_item_id")
        action = request.POST.get("action")

        # Get the cart item
        cart_item = get_object_or_404(CartItem, id=cart_item_id, cart__user=request.user)

        if action == "reduce":
            if cart_item.quantity > 1:
                cart_item.quantity -= 1
                cart_item.save()
            else:
                cart_item.delete()  # Remove the item if the quantity reaches 0
        elif action == "delete":
            cart_item.delete()

        return redirect('cart_summary')

# Checkout View
class CheckoutView(LoginRequiredMixin, View):
    def get(self, request):
        try:
            cart = Cart.objects.get(user=request.user, is_ordered=False)
        except Cart.DoesNotExist:
            return redirect("cart_summary")

        form = OrderForm()
        return render(request, "store/checkout.html", {"cart": cart, "form": form})

    def post(self, request):
        try:
            cart = Cart.objects.get(user=request.user, is_ordered=False)
        except Cart.DoesNotExist:
            return redirect("cart_summary")

        form = OrderForm(request.POST, request.FILES)

        if form.is_valid():
            order = form.save(commit=False)
            order.user = request.user
            order.total_price = cart.total_price()

            # Save the shipping address directly to the order
            order.address_line1 = form.cleaned_data['address_line1']
            order.address_line2 = form.cleaned_data['address_line2']
            order.city = form.cleaned_data['city']
            order.state = form.cleaned_data['state']
            order.zip_code = form.cleaned_data['zip_code']
            order.country = form.cleaned_data['country']
            order.payment_screenshot = form.cleaned_data['payment_screenshot']

            order.save()

            for item in cart.cart_items.all():
                if item.quantity > item.product.stock:
                    return HttpResponse(f"Not enough stock for {item.product.name}", status=400)
                OrderItem.objects.create(order=order, product=item.product, quantity=item.quantity)
                item.product.stock -= item.quantity
                item.product.save()

            cart.is_ordered = True
            cart.save()
            cart.clear_cart()

            Cart.get_or_create_cart(request.user)

            return redirect("order_confirmation", pk=order.pk)

        return render(request, "store/checkout.html", {"cart": cart, "form": form})

class OrderConfirmationView(LoginRequiredMixin, DetailView):
    model = Order
    template_name = "store/order_confirmation.html"
    context_object_name = "order"


# User Signup
from .forms import UserCreationFormWithProfile
class SignupView(View):
    def get(self, request):
        user_form = UserCreationFormWithProfile()
        profile_form = UserProfileForm()
        return render(request, 'store/signup.html', {
            'user_form': user_form,
            'profile_form': profile_form
        })

    def post(self, request):
        user_form = UserCreationForm(request.POST)
        profile_form = UserProfileForm(request.POST)
        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save()
            # Ensure UserProfile is created only if it doesn't already exist
            UserProfile.objects.get_or_create(user=user)
            return redirect('login')
        return render(request, 'store/signup.html', {
            'user_form': user_form,
            'profile_form': profile_form
        })


# Custom Login View
class CustomLoginView(View):
    def get(self, request):
        form = AuthenticationForm()
        return render(request, 'store/login.html', {'form': form})

    def post(self, request):
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('product_list')
            else:
                return HttpResponse("Invalid login credentials", status=401)
        else:
            return render(request, 'store/login.html', {'form': form})

# Custom Logout View
class CustomLogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('login')
    

#userprofile
class UserProfileView(TemplateView):
    template_name = 'store/profile.html'  # Use a separate template for displaying the profile

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['user'] = self.request.user  # Add the current user to the context
        return context


class MyOrdersView(LoginRequiredMixin, ListView):
    model = Order
    template_name = 'store/my_orders.html'
    context_object_name = 'orders'
    ordering = ['-created_at']
 
    def get_queryset(self):
        return Order.objects.filter(user=self.request.user)

class UserProfileUpdateView(LoginRequiredMixin, UpdateView):
    model = User
    form_class = UserProfileForm
    template_name = 'store/edit_profile.html'  # Template for editing the profile
    success_url = reverse_lazy('profile')  # Redirect to the profile page after update

    def get_object(self):
        return self.request.user

    def form_valid(self, form):
        messages.success(self.request, 'Your profile has been updated!')
        return super().form_valid(form)
