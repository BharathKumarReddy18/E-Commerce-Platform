from django import forms
from django.contrib.auth.models import User
from .models import Order, UserProfile,Product
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError

#Pruduct Search

class ProductSearchForm(forms.Form):
    query = forms.CharField(label='Search for products', max_length=100, required=False)
    # category_type = forms.ChoiceField(choices=[('', 'All Categories')] + Product.CATEGORY_TYPE_CHOICES, required=False)




# Order Form
class OrderForm(forms.ModelForm):
    address_line1 = forms.CharField(max_length=255, required=True)
    address_line2 = forms.CharField(max_length=255, required=False)
    city = forms.CharField(max_length=100, required=True)
    state = forms.CharField(max_length=100, required=True)
    zip_code = forms.CharField(max_length=20, required=True)
    country = forms.CharField(max_length=100, required=True)
    payment_screenshot = forms.ImageField(required=True)

    class Meta:
        model = Order
        fields = ['payment_screenshot']

    def clean_payment_screenshot(self):
        screenshot = self.cleaned_data.get("payment_screenshot")
        if not screenshot:
            raise ValidationError("You must upload a payment screenshot.")
        return screenshot

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name']  # You can add other fields as needed

class UserCreationFormWithProfile(UserCreationForm):
    email = forms.EmailField(required=True)  # Explicitly add the email field
 
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']  # Include email here
 
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']  # Save the email field value
        if commit:
            user.save()
        return user
 
 